#ifndef _BLOCK_O_
#define _BLOCK_O_
#include "abstractBlock.h"
#include <string>
#include <vector>
#include "point.h"
#include "abstractLevel.h"
class BlockO : public AbstractBlock {
    public:
        // constructor, put points into vectors, 
        // set the string/color of point
        // according to the block feature
        // maybe multiple constructor
        BlockO(int score);
        ~BlockO();
        void initialize(AbstractPlayer *p) override;
};
#endif
